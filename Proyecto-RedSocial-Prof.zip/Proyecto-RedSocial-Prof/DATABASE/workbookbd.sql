-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 18-10-2020 a las 00:40:07
-- Versión del servidor: 5.7.31
-- Versión de PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `workbookbd`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `friends`
--

DROP TABLE IF EXISTS `friends`;
CREATE TABLE IF NOT EXISTS `friends` (
  `my_friend_id` int(11) NOT NULL AUTO_INCREMENT,
  `my_id` int(11) NOT NULL,
  `friends_id` int(11) NOT NULL,
  PRIMARY KEY (`my_friend_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `friends`
--

INSERT INTO `friends` (`my_friend_id`, `my_id`, `friends_id`) VALUES
(1, 10, 0),
(11, 12, 0),
(12, 13, 0),
(13, 11, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `members`
--

DROP TABLE IF EXISTS `members`;
CREATE TABLE IF NOT EXISTS `members` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `cedula` int(20) NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `work` varchar(100) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `members`
--

INSERT INTO `members` (`member_id`, `firstname`, `lastname`, `address`, `email`, `age`, `gender`, `username`, `password`, `cedula`, `ciudad`, `titulo`, `image`, `mobile`, `status`, `work`) VALUES
(11, 'Mauricio', 'Sevilla', 'Calle 45 #16-23', 'mau@ug.edu.ec', 35, 'Hombre', 'configuroweb', '1234abcd..', 965231456, 'Guaayquil', 'Abagado', 'images/logo2.png', '3142450392', 'Activo', 'Juez Penal'),
(12, 'Maria', 'Galarza', 'Calle con Carrera', 'Mariaxd@gmail.com', 42, 'Hombre', 'usuario', '1234abcd..', 945256135, 'Guayaquiil', 'Arquictecto', 'images/mujer1.jpg', '3054679844', 'Activo', 'diseñador de interiores'),
(13, 'Zack', 'Efron', 'Cualquier Calle', 'netflix21@apple.com', 18, 'Hombre', 'lee', '1234abcd..', 1054982654, 'Cuenca', 'Medico Cirujano', 'images/zack1.jpg', '3167894167', 'Casado', 'Medico'),
(14, 'Masha ', 'Cifuentes', 'calle 4ta', 'pepe@gmail.com', 21, 'masculino', 'Mash13', '123456', 956321545, 'Quito', 'Ingenieria en Sistemas', 'jpg', '0965325684', 'soltero', 'Medico Cirujano'),
(15, 'Ignacio', 'Moriel', 'colinas dela Alborada', 'jmoriel@gmail.com', 25, 'masculino', 'Nashoo', '123456', 956321545, 'Guyaquil', 'Ingenieria en Sistemas', 'images/moriel.jpeg', '0945163285', 'soltero', 'Disenador web'),
(16, 'El', 'Rosado', '9 de octubre y boyaca ', 'elrosado.com.ec', 41, 'no definido', 'elrosado', 'elrosa', 1024518745, 'Guayaquil', 'Retail', 'images/rosadox1.jpg', '0956214585', 'no definido', 'Cajero'),
(18, 'Novacero', '', 'Km 26 via a daule', 'novacero.com.ec', 36, 'no definido', 'no01', 'metal1', 32645865, 'Guayaquil', 'Contadores', 'images/nova.jpg', '09531575', '', 'Contadores');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `reciever_id` int(11) NOT NULL,
  `content` varchar(100) NOT NULL,
  `date_sended` varchar(100) NOT NULL,
  PRIMARY KEY (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `message`
--

INSERT INTO `message` (`message_id`, `sender_id`, `reciever_id`, `content`, `date_sended`) VALUES
(1, 10, 1, 'hello', '2019-02-27 18:12:48'),
(2, 11, 12, 'Hola amiguis', '2020-03-12 10:40:26'),
(3, 12, 11, 'hola man como vas', '2020-03-12 10:40:53'),
(4, 12, 11, 'Hola', '2020-03-12 11:21:30'),
(5, 11, 12, 'Bien man', '2020-03-12 11:22:58'),
(6, 12, 11, 'MP', '2020-03-12 20:04:44'),
(7, 13, 11, 'Hola amigo secreto', '2020-03-12 20:09:44'),
(8, 13, 12, 'hola como estas?', '2020-10-17 01:42:48');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `note`
--

DROP TABLE IF EXISTS `note`;
CREATE TABLE IF NOT EXISTS `note` (
  `note_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `message` varchar(200) NOT NULL,
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `note`
--

INSERT INTO `note` (`note_id`, `date`, `message`) VALUES
(6, '', 'Doc terry will be  out on august 3 2013');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `photos_id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(100) NOT NULL,
  `member_id` int(11) NOT NULL,
  PRIMARY KEY (`photos_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `photos`
--

INSERT INTO `photos` (`photos_id`, `location`, `member_id`) VALUES
(1, 'upload/7918240442_4471d5b11e_b.jpg', 1),
(2, 'upload/Como dar Like Automatico por Palabra Clave en Twitter con Python.png', 11),
(3, 'upload/Como Aumentar tus Seguidores en Instagram con Instabot Python.png', 11),
(4, 'upload/como instalar wordpress en local con xampp.png', 11),
(7, 'upload/como descargar video de Instagram Facebook Twitter Youtube Linkedin desde el Movil.jpg', 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE IF NOT EXISTS `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `date_posted` varchar(100) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `post`
--

INSERT INTO `post` (`post_id`, `member_id`, `content`, `date_posted`) VALUES
(9, 11, 'Hola a todos estoy feliz de poder interactuar en esta red social', '2020-03-12 20:02:27'),
(10, 13, 'Me place mucho acceder a esta nueva gran red social', '2020-03-12 20:11:03'),
(11, 13, 'ya es de tarde ', '2020-10-16 16:20:26'),
(12, 16, 'Venta al por menor de gran variedad de productos entre los que predominan, los productos alimenticios, las bebidas o el tabaco, como productos de primera necesidad y varios otros tipos de productos, como prendas de vestir, muebles, aparatos, artÃ­culos.', '2020-10-17 01:12:13'),
(13, 12, 'Soy Maria Galarza y me desempeÃ±o en administrar y gestionar proyectos soy responsable dedica y comprometida con mi trabajo', '2020-10-17 01:19:47'),
(14, 18, 'NOVACERO S.A. dedicada a fabricaciÃ³n de barras, varillas y secciones sÃ³lidas de hierro y acero laminadas en caliente y mediante estirado en frÃ­o y en caliente,', '2020-10-17 01:22:55'),
(15, 13, 'Hola con todos me llamo Zack Efron y soy programador en python con maestria en Cambrigde, tambien diseÃ±o paginas web como pasatiempos.', '2020-10-17 02:14:56');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `schedule`
--

DROP TABLE IF EXISTS `schedule`;
CREATE TABLE IF NOT EXISTS `schedule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `service_id` int(11) NOT NULL,
  `Number` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `schedule`
--

INSERT INTO `schedule` (`id`, `member_id`, `date`, `service_id`, `Number`, `status`) VALUES
(76, 1, '11/09/2013', 1, 1, 'Done'),
(77, 1, '11/09/2013', 1, 1, 'Pending'),
(78, 1, '10/09/2013', 1, 1, 'Done');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `service`
--

DROP TABLE IF EXISTS `service`;
CREATE TABLE IF NOT EXISTS `service` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_offer` varchar(100) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `service`
--

INSERT INTO `service` (`service_id`, `service_offer`, `price`) VALUES
(1, 'Cleaning', '700.00'),
(2, 'q', '100.00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`) VALUES
(5, 'configuroweb', '1234abcd..');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
