<!DOCTYPE html>
<html lang="es">
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
        <title>Workbook</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <!---     <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-glyphicons.css" type="text/css" rel="stylesheet">
		<link href="css/font-awesome.css" type="text/css" rel="stylesheet">
        <link href="css/my_style.css" type="text/css" rel="stylesheet"> -->
        <!-- Iconos -->
        
		<link href="css/font-awesome.css" type="text/css" rel="stylesheet">
        <link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">
        <link href="css/estiloscomercio1.css" type="text/css" rel="stylesheet"> 
        <!--Animacion de ciertas Etiquetas-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
            integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
         <!--Efecto Scroll en imagen-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="login/parallax.min.js"></script>
        <script src="login/validacionlogin.js"></script>    
	</head>
	<?php include('dbcon.php'); ?>