<div>
	<h1 style="padding-top: 50px;">Tu Perfil </h1>
	<div class="row">
		<div class="col-md-2">
			<hr>
			<center><img class="pp" src="<?php echo $image; ?>" height="140" width="160"></center>
			<hr>
			<br>

		</div>
		<div class="col-md-10">
			<hr>
			<div class="pull-right"><a href="edit_profile.php" class="btn btn-info"><i class="icon-pencil"></i>
					Editar</a></div>
			<h3>Información Personal</h3>
			<?php
			$query = $conn->query("select * from members where member_id = '$session_id'");
			$row = $query->fetch();
			$id = $row['member_id'];
			?>
			<hr>
			<div class="row mx-md-n5">
				<div class="col px-md-5">
					<div class="p-3 border bg-light">
						<p>Nombre: &nbsp <?php echo $row['firstname']." ".$row['lastname']; ?><span class="margin-p"></span>
						<br>
						Cedula: &nbsp &nbsp &nbsp<?php echo $row['cedula']; ?>
						<br>
						Titulo: &nbsp &nbsp &nbsp <?php echo $row['titulo']; ?>
						<br>
						Correo: &nbsp &nbsp <?php echo $row['email']; ?>
						<br>
						Celular: &nbsp &nbsp <?php echo $row['mobile']; ?>
						<br>
						Usuario: &nbsp &nbsp <?php echo $row['username']; ?>
						<br>
						Email: &nbsp &nbsp &nbsp &nbsp<?php echo $row['email']; ?>
					</div>
				</div>
				<div class="col px-md-5">
					<div class="p-3 border bg-light">
						<br>
						Estado Civil: &nbsp <?php echo $row['status']; ?>
						<br>
						Trabajo: &nbsp &nbsp <?php echo $row['work']; ?>
						<br>
						Direccion: &nbsp &nbsp <?php echo $row['address']; ?>
						<br>
						Ciudad: &nbsp &nbsp <?php echo $row['ciudad']; ?>
						<br>
						Edad: &nbsp &nbsp &nbsp &nbsp <?php echo $row['age']; ?> años
						<br>
						Genero: &nbsp &nbsp <?php echo $row['gender']; ?></p>
					</div>
					
				</div>
			</div>
		</div>

	</div>
</div>