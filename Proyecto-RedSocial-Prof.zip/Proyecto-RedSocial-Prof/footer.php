<hr>

<footer class="bgDark">
		<div class="container">
			<h2 style="font-size: 30px"> <span><b>WorkBook</b></span></h2>
			<ul class="list-inline">
				<li class="list-inline-item footer-menu"><a href="formulariocontac.php">Contact</a></li>
				<li class="list-inline-item footer-menu"><a href="terminoycondiciones.php">Termino y Condiciones</a></li>
			</ul>
			<ul class="list-inline">
				<li class="list-inline-item"><a href="http://www.instagram.com"><i
							class="icon ion-logo-instagram"></i></a></li>
				<li class="list-inline-item"><a href="http://www.facebook.com"><i
							class="icon ion-logo-facebook"></i></a></li>
				<li class="list-inline-item"><a href="http://www.youtube.com"><i class="icon ion-logo-youtube"></i></a>
				</li>
				<li class="list-inline-item"><a href="http://www.whatsapp.com"><i
							class="icon ion-logo-whatsapp"></i></a></li>
				<li class="list-inline-item"><a href="http://www.twitter.com"><i class="icon ion-logo-twitter"></i></a>
				</li>
			</ul>
			<small><b>Desarrollo de Aplicaicones WEB UG.</b> ©2020 All Rights Reserved. Created by Grupo </small>
		</div>
	</footer>
        
        <!--<script type='text/javascript' src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>


        <script type='text/javascript' src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
        <script type='text/javascript'>
        
        $(document).ready(function() {
        
      
        });
        
        </script>



        
        <!-- JavaScript jQuery code from Bootply.com editor -->
        
        