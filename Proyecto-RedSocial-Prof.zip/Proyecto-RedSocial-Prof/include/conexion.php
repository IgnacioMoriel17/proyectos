<?php
 $host = "localhost";
 $user = "root";
 $clave = "";
 $bd = "workbookbd";
 $conectar = mysqli_connect($host,$user,$clave,$bd);
 ?>