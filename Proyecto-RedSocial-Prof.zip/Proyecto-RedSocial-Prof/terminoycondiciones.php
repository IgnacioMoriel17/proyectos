<?php include('index_header_term.php'); ?>    
<?php include('session.php'); ?>    
<body>
<?php include('navbar.php'); ?>
	  
	

    
    <div class="letracentro">
        <h1>Terminos y Condiciones del Servicio <span>WorkBook</span></h1>
    </div>

    <section>
        <div class="contenedor">
            <div class="descrip_img">
                <div class="letras">
                    <h2>1. Quién puede hacer uso de los Servicios</h2>
                    <p>Puede hacer uso de los Servicios si usted cuenta con un titulo de tercer nivel, tecnico superior,
                        maestria, doctorado o ser propietario de una empresa, microempra o franquicia registradas en el
                        SRI y no es usted una persona vetada para hacer uso de los servicios de conformidad con la
                        legislación de su jurisdicción aplicable.<br>
                        En cualquier caso, usted deberá ser mayor de 18 años y no tener cargos judiciales, para hacer
                        uso de los Servicios. Si acepta estos Términos y usa los Servicios en nombre de una empresa,
                        organización, gobierno u otra entidad jurídica, afirma y garantiza que está autorizado a hacerlo
                        y cuenta con los poderes necesarios para obligarla al cumplimiento de estos Términos.</p>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="contenedor">
            <div class="descrip_img2">
                <div class="letras">
                    <h2>2. Privacidad</h2>
                    <p>WorkBook es público y las publicaciones pueden ser vistos y buscados por cualquier persona en
                        todo el mundo. También le proporcionamos formas de comunicarse en WorkBook que no son públicas
                        mediante publicaciones protegidos y Mensajes directos. Usted también puede utilizar WorkBook
                        bajo un seudónimo si prefiere no utilizar su nombre.<br>
                        Cuando usted utiliza WorkBook, incluso si solo está mirando publicaciones, recibimos alguna
                        información personal de usted como el tipo de dispositivo que está utilizando y su dirección IP.
                        Usted puede optar por compartir información adicional con nosotros como su dirección de correo
                        electrónico, número de teléfono, contactos de la agenda y perfil público. Utilizamos esta
                        información para cuestiones como el mantenimiento de la seguridad de su cuenta y para mostrarle
                        publicaciones, personas que seguir, eventos y anuncios más relevantes.</p>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="contenedor">
            <div class="descrip_img3">
                <div class="letras">
                    <h2>3. Contenido de los Servicios</h2>
                    <p>Cualquier confianza que deposite en cualquier Contenido o material publicado por medio de los
                        Servicios u obtenido mediante los mismos, o cualquier uso que haga de ellos, lo hace por su
                        propia cuenta y riesgo. <br>
                        Cualquier confianza que deposite en cualquier Contenido o material publicado por medio de los
                        Servicios u obtenido mediante los mismos, o cualquier uso que haga de ellos, lo hace por su
                        propia cuenta y riesgo. No ratificamos, apoyamos, reafirmamos ni garantizamos la compleción,
                        veracidad, precisión o fiabilidad de ningún Contenido o comunicación publicada por medio de los
                        Servicios, ni ratificamos ninguna opinión expresada por medio de los Servicios.</p>
                </div>
            </div>
        </div>
    </section>



    <?php include('footer.php'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>
</body>

</html>