<?php include('header.php'); ?>
<?php include('session.php'); ?>

<body>
    <?php include('navbar.php'); ?>

    <main>
        <section id="estudiantes" class="divider">
            <h2 style="text-align: center;padding: 20px; font-weight: 500">Acerca de nosotros </h2>
            <h3 style="text-align: center;padding: 20px; font-weight: 300">Somos Estudiantes de la Facultad de
                Ingenieria en Sistemas Computacionales y hemos desarrollado una red social para profecionales y para
                empresas con la finalidad de sus agrado ;) </h3>
            <div class="container">
                <div class="content-center">
                    <div >
                        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="carousel-container">
                                        <p>Hola mi nombre es Ignacio Moriel y soy responsable del diseno de la pag web
                                            como
                                            pasatiempos tengo hacer ejercicio y me gusta mucho la Programacion
                                        </p>
                                        <div class="rating">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="estudiantes-user">
                                            <div class="row">
                                                <div class="col-md-4 col-4">
                                                    <img src="images/moriel.jpeg" class="img-fluid" alt="">
                                                </div>
                                                <div class="col-md-9 col-9">
                                                    <h6 >Ignacio Moriel</h6>
                                                    <span>Diseño con CSS y Bootstrap</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-container">
                                        <p>Hola mi nombre es Ma.Angeles me gusta mucho la carrera, en especial las
                                            materias
                                            de programacion. Hobbie favorito es ver peliculas.</p>
                                        <div class="rating">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="estudiantes-user">
                                            <div class="row">
                                                <div class="col-md-4 col-4">
                                                    <img src="images/briones.jpg" class="img-fluid" alt="">
                                                </div>
                                                <div class="col-md-9 col-9">
                                                    <h6>Maria de Los Angeles Briones</h6>
                                                    <span>Desarrollo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-container">
                                        <p>Soy una persona emprendedora, que adora los retos y no se rinde fácilmente.
                                            Me encanta aprender cosas nuevas cada día. carácter fuerte pero con un
                                            corazón noble para ayudar a los demás.</p>
                                        <div class="rating">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="estudiantes-user">
                                            <div class="row">
                                                <div class="col-md-4 col-4">
                                                    <img src="images/margarita.png" class="img-fluid" alt="">
                                                </div>
                                                <div class="col-md-9 col-9">
                                                    <h6>Margarita Nuñez</h6>
                                                    <span>Desarrollo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-container">
                                        <p>Mi nmbre es Paulina y me gusta mucho la informatica  como pasatiempos tengo escuchar musica y cantar ;)</p>
                                        <div class="rating">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="estudiantes-user">
                                            <div class="row">
                                                <div class="col-md-4 col-4">
                                                    <img src="images/paulina.jpg" class="img-fluid" alt="">
                                                </div>
                                                <div class="col-md-9 col-9">
                                                    <h6>Paulina Sojos</h6>
                                                    <span>Desarrollo</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <div class="carousel-container">
                                        <p>Mi nombres es Kevin García, cuento con 23 años. Mi perfil profesional apunta
                                            al
                                            desarrollo de aplicaciones en diferentes tipos de lenguaje, soporte técnico
                                            a
                                            equipos de cómputo preventivos y correctivos, colaborativo en el área de
                                            trabajo, sociable y dispuesto ayudar con dudas e inquietudes sobre la
                                            carrera de
                                            ingeniería en sistemas computacionales.</p>
                                        <div class="rating">
                                            <ul class="list-inline">
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                                <li class="list-inline-item"><i class="icon ion-md-star"></i></li>
                                            </ul>
                                        </div>
                                        <div class="estudiantes-user">
                                            <div class="row">
                                                <div class="col-md-4 col-4">
                                                    <img src="images/garcia1.jpg" class="img-fluid" alt="">
                                                </div>
                                                <div class="col-md-9 col-9">
                                                    <h6>Gracia Chamba</h6>
                                                    <span>Validaciones</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button"
                                data-slide="prev">
                                <div class="control-button">
                                    <img src="images/iconos/arrow-borderless-left.svg" class="img-fluid" alt="arrowl">
                                </div>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button"
                                data-slide="next">
                                <div class="control-button">
                                    <img src="images/iconos/arrow-borderless-right.svg" class="img-fluid" alt="arrowr">
                                </div>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>
    <footer class="bgDark">
        <div class="container">
            <h2 style="font-size: 30px; color:rgb(95, 204, 255)"><b>WorkBook</b></h2>
            <ul class="list-inline">
                

                <li class="list-inline-item footer-menu"><a href="formulariocontac.php">Contact</a></li>
                <li class="list-inline-item footer-menu"><a href="terminoycondiciones.php">Termino y Condiciones</a>
                </li>
            </ul>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="http://www.instagram.com"><i
                            class="icon ion-logo-instagram"></i></a></li>
                <li class="list-inline-item"><a href="http://www.facebook.com"><i
                            class="icon ion-logo-facebook"></i></a></li>
                <li class="list-inline-item"><a href="http://www.youtube.com"><i class="icon ion-logo-youtube"></i></a>
                </li>
                <li class="list-inline-item"><a href="http://www.whatsapp.com"><i
                            class="icon ion-logo-whatsapp"></i></a></li>
                <li class="list-inline-item"><a href="http://www.twitter.com"><i class="icon ion-logo-twitter"></i></a>
                </li>
            </ul>
            <small>©2020 All Rights Reserved. Created by Grupo <b>D.A.W con Bootstrap</b></small>
        </div>
    </footer>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>

</body>

</html>