        
     <?php
            $session_id = $_SESSION['id'];
            $query = $conn->query("select * from members where member_id = '$session_id'");
            $row = $query->fetch();
            $posted_by = $row['firstname']." ".$row['lastname'];
            
            ?>

<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand nav-link disabled animate__animated animate__slideInLeft"
            style="font-size: 35px; color: white;">Bienvenido a <span
                style="color: rgb(95, 204, 255);">WorkBook</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class="icon ion-md-menu"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item pt-2 active"><a class="nav-link" href="home.php" id="inicio">Publicaciones</a></li>
                <li class="nav-item pt-2 active"><a class="nav-link" href="friends.php" id="agregados">Agregados</a></li>
                <li class="nav-item pt-2 active"><a class="nav-link" href="message.php" id="mensajes">Mensajes</a></li>
                <li class="nav-item pt-2"><a class="nav-link" href="acercade.php" id="acerca">Acerca de Nosotros</a>
                <li class="nav-item "><a class="nav-link" href="profile.php" id="user" style="font-size: 23px;font-weight: 600 ;color:  rgb(95, 204, 255)"><?php echo $posted_by; ?></a>
                </li>
                <li class="nav-item pt-2"><a class="nav-link" href="logout.php" id="salir">Salir</a></li>
            </ul>

        </div>
    </div>
</nav>