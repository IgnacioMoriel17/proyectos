<?php 

include("../include/conexion.php");
		 

if (isset($_POST['register'])) {
	if (strlen($_POST['name']) >= 1 && strlen($_POST['apellido']) >= 1 && strlen($_POST['user']) >= 1 
	&& strlen($_POST['pass']) >= 1 && strlen($_POST['cedu']) >= 1 && strlen($_POST['edad']) >= 1 
	&& strlen($_POST['email']) >= 1 && strlen($_POST['cel']) >= 1 && strlen($_POST['dir']) >= 1 
	&& strlen($_POST['ciudad']) >= 1 && strlen($_POST['titulo']) >= 1 && strlen($_POST['prof']) >= 1  
	&& strlen($_POST['estado']) >= 1 && strlen($_POST['gener']) >= 1 && strlen($_POST['img']) >= 1) {
		$name	= trim($_POST['name']);
		$apell	= trim($_POST['apellido']);
	    $user 	= trim($_POST['user']);
	    $pass 	= trim($_POST['pass']);
		$cedu 	= trim($_POST['cedu']);
		$edad 	= trim($_POST['edad']);
	    $email 	= trim($_POST['email']);
	    $cel 	= trim($_POST['cel']);
	    $dir 	= trim($_POST['dir']);
	    $ciudad = trim($_POST['ciudad']);
	    $titulo = trim($_POST['titulo']);
		$prof 	= trim($_POST['prof']);
		$estado = trim($_POST['estado']);
		$gener 	= trim($_POST['gener']);
		$img 	= trim($_POST['img']);

	    $consulta = "INSERT INTO  members(firstname, lastname, username, password , cedula, age, email, mobile, address, ciudad, titulo, work, status, gender, 	image) 
		VALUES ('$name', '$apell','$user', '$pass', '$cedu', '$edad' , '$email', '$cel', '$dir', '$ciudad', '$titulo', '$prof', '$estado', '$gener', '$img' )";

		$resultado = mysqli_query($conectar,$consulta);
		
				

	    if ($resultado) {
			
	    	?> 
	    	<h3 class="ok">¡Te has registrado correctamente! :) <a href="../index.php" style="text-decoration: none;">Login</a>	</h3>
           <?php
	    } else {
	    	?> 
	    	<h3 class="bad">¡Ups ha ocurrido un error! :(</h3>
           <?php
	    }
    }   else {
	    	?> 
	    	<h3 class="bad">¡Por favor complete los campos! >:/</h3>
           <?php
	}
	
}

?>