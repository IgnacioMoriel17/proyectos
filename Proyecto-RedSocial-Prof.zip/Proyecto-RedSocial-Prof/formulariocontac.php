<?php include('index_header_contact.php'); ?>    
<?php include('session.php'); ?>  

<body>
<?php include('navbar.php'); ?>
	  
	
	<main>
	<section>
		<div>
		<h2 style="text-align: center;padding: 20px; font-weight: 300">Alguna duda?, ponte en contacto con nosotros.</h2>	
		</div>
	</section>
		
	<section>
		<div>
			<form class="formulario">
				 <strong>Nombre <sup>*</sup> </strong>: <input type="text" name="nombre" id="nombre" placeholder="Nombre"><br><br>
              	
		  		 <strong>Correo Electronico Personal <sup>*</sup> </strong>: <input type="email" name="email" id="email"
               	 placeholder="ejemplo@mail.com"> <br><br>
				 
				 <strong>Asunto <sup>*</sup> </strong>: <input type="text" name="asunto" id="asunto" placeholder="escriba el Asunto"><br><br>
				
				<div class="cuadro">
				<strong>Escriba  el asunto que solicita <sup>*</sup> </strong>:<br><br>
				<textarea name="descripcion" id="descripcion" rows="7" cols="70" placeholder="Escriba el Asunto aqui ;)" style="border-radius: 30px; text-align: center"></textarea> <br><br>
				</div>
				
				 <button type="submit" id="enviar">Enviar datos</button>
			</form>
		</div>	
	</section>
	
	</main>
	
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
        crossorigin="anonymous"></script>
</body>
</html>
