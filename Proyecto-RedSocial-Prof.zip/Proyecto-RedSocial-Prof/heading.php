<div style="padding-top: 10px;">
	<h1 style="text-align: center; padding-top: 20px; ">Publicaciones</h1>
	<hr>
	<div class="row" >
		<div class="col-md-2">
			
			<center><img class="pp" src="<?php echo $image; ?>" height="140" width="160"></center>
			<br>

		</div>
		<div class="col-md-5" >
			
			
			<h3 >Información Personal</h3>
			<?php
			$query = $conn->query("select * from members where member_id = '$session_id'");
			$row = $query->fetch();
			$id = $row['member_id'];
			?>
			<hr>
			<p>Nombre: &nbsp <?php echo $row['firstname']." ".$row['lastname']; ?><span class="margin-p"></span>
				<br>
				Titulo: &nbsp &nbsp &nbsp <?php echo $row['titulo']; ?>
				<br>
				Correo: &nbsp &nbsp <?php echo $row['email']; ?></p>
			<a class="btn btn-success" href="change_pic.php">Cambiar Foto de Perfil</a>
			<hr>

		</div>



		<div class="col-md-5">
			<form method="post" action="post.php">
				
				
				<h4>Publicar:</h4>
				<textarea name="content" rows="6" cols="70"
					placeholder="  &nbsp Escribe tu publicacion aqui, escribe tus habilidades y destrezas como  &nbsp &nbsp profesional o si necesitas algun servicio. ;)"></textarea>
				<br>
				<button class="btn btn-success"><i class="icon-share"></i> Compartir </button>
				<hr>
			</form>
		</div>
	</div>
</div>