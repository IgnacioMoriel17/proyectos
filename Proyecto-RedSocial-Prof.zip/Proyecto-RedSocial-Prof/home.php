<?php include('header.php'); ?>
<?php include('session.php'); ?>

<body>
  <?php include('navbar.php'); ?>
  <div id="masthead">
    <div class="container">
      <?php include('heading.php'); ?>
    </div><!-- /cont -->
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="top-spacer"> </div>
        </div>
      </div>
    </div><!-- /cont -->
  </div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="panel">
          <div class="panel-body">
            <!--/stories-->
            <h3>Lo mas Reciente..</h3>
            <hr>
            <div class="row  border border-secondary">
              <br>
                <?php
              $query = $conn->query("select * from post LEFT JOIN members on members.member_id = post.member_id order by post_id DESC");
              while($row = $query->fetch()){
              $posted_by = $row['firstname']." ".$row['lastname'];
              $posted_image = $row['image'];
              $id = $row['post_id'];
              ?>
              
              <div class="col-md-2 col-sm-3 text-center" style="padding-top: 25px;">
                <img src="<?php echo $posted_image; ?>" style="width:120px;height:120px" class="rounded-circle"></a>
              </div>
              <div class="col-md-10 col-sm-9 " style="" >
                <div class="alert"><h4><?php echo $row['content']; ?></h4></div>
                <div class="row">
                  <div class="col-xs-9">
                    <p><span class="label label-info"> <?php echo $row['date_posted']; ?></span></p>
                    <h3>
                      <small style="" class="text-muted">Posteado por:<a 
                          class="text-muted">&nbsp <?php echo $posted_by; ?></a></small></h3>
                  </div>
                  <br>
                  <div class="col-xs-3"><a href="delete_post.php<?php echo '?id='.$id; ?>" class="btn btn-success"><i
                        class="icon-share"></i> ELIMINAR :( </a></div>
                </div>
                <hr>
              </div>
               
              <?php } ?> 
            </div>
            
          </div>
        </div>



      </div>
      <!--/col-12-->
    </div>
  </div>


  <?php include('footer.php'); ?>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
    integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
    integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
    crossorigin="anonymous"></script>
</body>

</html>