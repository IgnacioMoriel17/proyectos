<?php
    require('Controller/controlador.php');
?>