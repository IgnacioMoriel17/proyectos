<?php

require('Model/modelo.php');

$con = new Conexion();

$usuarios = $con->getUsers();

require('Views/vista.phtml');

?>